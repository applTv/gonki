package com.example.gonki;

public class Data {
    public static String playerName = "Player";
}
